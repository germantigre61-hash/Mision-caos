plugins { id("com.android.application") }

android {
    namespace = "com.madeforyou.misioncaos"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.madeforyou.misioncaos"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
}
