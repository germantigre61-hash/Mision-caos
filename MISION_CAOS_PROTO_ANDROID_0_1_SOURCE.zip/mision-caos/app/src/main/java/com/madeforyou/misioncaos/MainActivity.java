package com.madeforyou.misioncaos;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class MainActivity extends Activity {
    private static final String SERVICE = "com.madeforyou.misioncaos.v1";
    private static final Strategy STRATEGY = Strategy.P2P_STAR;
    private static final int PERMISSION_REQUEST = 70;
    private final int NAVY = Color.rgb(23,34,63), CORAL = Color.rgb(255,107,97), MINT = Color.rgb(101,214,195), CREAM = Color.rgb(255,248,237);

    private ConnectionsClient nearby;
    private LinearLayout root, playersBox;
    private EditText nameInput;
    private TextView status, title;
    private Button startButton;
    private boolean host = false, gameRunning = false, taskDone = false;
    private String playerName = "", hostEndpoint = null;
    private final Map<String,String> players = new LinkedHashMap<>();
    private final Map<String,Boolean> completed = new LinkedHashMap<>();
    private CountDownTimer timer;

    private final String[] missions = {
        "Encontrá a dos jugadores y formen un triángulo con sus celulares.",
        "Conseguí que tres personas digan al mismo tiempo: MISIÓN ACEPTADA.",
        "Descubrí quién recibió una misión relacionada con un color.",
        "Elegí a alguien y copien exactamente la misma pose durante 5 segundos.",
        "Ordenen a cuatro jugadores por mes de cumpleaños sin hablar.",
        "Lográ que todo el grupo levante un brazo en menos de 10 segundos.",
        "Intercambiá una palabra secreta con otro jugador sin que el resto la oiga.",
        "Encontrá algo azul y mostralo al grupo antes de que pasen 30 segundos.",
        "Hacé reír a otra persona sin tocarla.",
        "Formen una fila por altura sin usar palabras."
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); nearby = Nearby.getConnectionsClient(this); showHome(); requestPermissionsIfNeeded();
    }

    private void showHome() {
        host=false; gameRunning=false; players.clear(); completed.clear(); stopNetwork();
        root = base();
        label("MISIÓN CAOS", 34, Color.WHITE, true, 0, 18);
        label("Un juego presencial. Muchos celulares. Cero internet.", 18, Color.rgb(210,218,235), false, 0, 34);
        nameInput = new EditText(this); nameInput.setHint("Tu nombre"); nameInput.setTextColor(NAVY); nameInput.setHintTextColor(Color.GRAY); nameInput.setTextSize(18); nameInput.setSingleLine(true); nameInput.setPadding(22,0,22,0); nameInput.setBackground(round(CREAM,18)); add(nameInput,-1,58,0,0,0,18);
        addButton("CREAR SALA", CORAL, this::createRoom);
        addButton("UNIRME A UNA SALA", MINT, this::joinRoom);
        label("Prototipo 0.1 · Para probar con 3 a 8 personas",14,Color.rgb(158,169,193),false,0,0);
        setContentView(scroll(root));
    }

    private void createRoom(View v) {
        if(!checkName() || !hasPermissions()) return;
        host=true; players.put("HOST",playerName); completed.put("HOST",false); showLobby();
        AdvertisingOptions opts = new AdvertisingOptions.Builder().setStrategy(STRATEGY).build();
        nearby.startAdvertising(playerName,SERVICE,connectionLifecycle,opts)
                .addOnSuccessListener(x->setStatus("Sala abierta. Los demás ya pueden buscarla."))
                .addOnFailureListener(e->setStatus("No pude abrir la sala: "+e.getMessage()));
    }

    private void joinRoom(View v) {
        if(!checkName() || !hasPermissions()) return;
        host=false; showSearching();
        DiscoveryOptions opts = new DiscoveryOptions.Builder().setStrategy(STRATEGY).build();
        nearby.startDiscovery(SERVICE, discovery, opts)
                .addOnFailureListener(e->setStatus("No pude buscar salas: "+e.getMessage()));
    }

    private boolean checkName(){ playerName=nameInput.getText().toString().trim(); if(playerName.length()<2){toast("Escribí tu nombre");return false;} return true; }

    private void showSearching(){
        root=base(); label("BUSCANDO SALA…",28,Color.WHITE,true,0,10); status=label("Acercate al teléfono que creó la partida.",17,Color.rgb(210,218,235),false,0,32);
        addButton("CANCELAR",CORAL,v->showHome()); setContentView(scroll(root));
    }

    private void showLobby(){
        root=base(); title=label(host?"SALA ABIERTA":"CONECTADO",28,Color.WHITE,true,0,8); status=label(host?"Esperando jugadores…":"Esperando que el anfitrión comience…",16,Color.rgb(210,218,235),false,0,20);
        playersBox=new LinearLayout(this); playersBox.setOrientation(LinearLayout.VERTICAL); playersBox.setPadding(18,18,18,18); playersBox.setBackground(round(Color.WHITE,18)); add(playersBox,-1,-2,0,0,0,22); renderPlayers();
        if(host){ startButton=button("EMPEZAR MISIÓN",CORAL); startButton.setEnabled(false); startButton.setOnClickListener(this::startGame); root.addView(startButton,params(-1,58,0,8,0,0)); }
        Button leave=button("SALIR",Color.rgb(70,82,110)); leave.setOnClickListener(v->showHome()); root.addView(leave,params(-1,54,0,10,0,0)); setContentView(scroll(root));
    }

    private void renderPlayers(){
        if(playersBox==null)return; playersBox.removeAllViews();
        if(players.isEmpty()){smallIn(playersBox,"Conectando…",Color.DKGRAY);return;}
        int n=1; for(String p:players.values()) smallIn(playersBox,String.format(Locale.getDefault(),"%02d   %s",n++,p),NAVY);
        if(host && startButton!=null){startButton.setEnabled(players.size()>=3); startButton.setAlpha(players.size()>=3?1f:.45f);}
    }

    private void startGame(View v){
        if(players.size()<3){toast("Se necesitan al menos 3 jugadores");return;}
        nearby.stopAdvertising(); gameRunning=true;
        List<String> ids=new ArrayList<>(players.keySet()); Collections.shuffle(ids);
        String infiltrator=ids.size()>=5?ids.get(0):""; int i=0;
        for(String id:ids){String role=id.equals(infiltrator)?"INFILTRADO":"AGENTE";String mission=id.equals(infiltrator)?"Evitá que completen todas las misiones sin revelar tu identidad.":missions[i++%missions.length];String msg="START|"+role+"|"+mission+"|300"; if(id.equals("HOST")) showMission(role,mission,300); else send(id,msg);}
        broadcast("PLAYERS|"+players.size());
    }

    private void showMission(String role,String mission,int seconds){
        gameRunning=true; taskDone=false; root=base(); label(role,15,role.equals("INFILTRADO")?CORAL:MINT,true,0,12); label("TU MISIÓN SECRETA",27,Color.WHITE,true,0,18);
        TextView card=label(mission,22,NAVY,true,26,28); card.setBackground(round(CREAM,22));
        TextView time=label("05:00",42,Color.WHITE,true,0,18); status=label("Misiones completadas: 0",16,Color.rgb(210,218,235),false,0,20);
        Button done=button(role.equals("INFILTRADO")?"LANZAR FALSA ALARMA":"MISIÓN COMPLETADA",role.equals("INFILTRADO")?CORAL:MINT); done.setOnClickListener(v->{if(taskDone)return;taskDone=true;done.setEnabled(false);done.setText("ENVIADO");if(host)markDone("HOST");else send(hostEndpoint,"DONE|"+playerName);});root.addView(done,params(-1,62,0,8,0,0)); setContentView(scroll(root));
        if(timer!=null)timer.cancel(); timer=new CountDownTimer(seconds*1000L,1000){public void onTick(long ms){long s=ms/1000;time.setText(String.format(Locale.getDefault(),"%02d:%02d",s/60,s%60));}public void onFinish(){time.setText("00:00"); if(host)finishGame(false);}}.start();
    }

    private void markDone(String id){
        if(!host||Boolean.TRUE.equals(completed.get(id)))return; completed.put(id,true); int count=0; for(Boolean b:completed.values())if(Boolean.TRUE.equals(b))count++; broadcast("PROGRESS|"+count+"|"+players.size()); if(status!=null)status.setText("Misiones completadas: "+count+" / "+players.size()); if(count>=players.size())finishGame(true);
    }

    private void finishGame(boolean won){ if(!host)return; String msg="END|"+(won?"WIN":"LOSE"); broadcast(msg); showResult(won); }
    private void showResult(boolean won){ if(timer!=null)timer.cancel(); gameRunning=false; root=base(); label(won?"MISIÓN CUMPLIDA":"TIEMPO AGOTADO",34,won?MINT:CORAL,true,0,18);label(won?"El equipo venció al caos.":"El caos ganó esta ronda.",21,Color.WHITE,true,0,30);addButton("VOLVER AL INICIO",CORAL,v->showHome());setContentView(scroll(root)); }

    private final EndpointDiscoveryCallback discovery=new EndpointDiscoveryCallback(){
        public void onEndpointFound(@NonNull String id,@NonNull DiscoveredEndpointInfo info){nearby.stopDiscovery();setStatus("Sala encontrada. Conectando…");nearby.requestConnection(playerName,id,connectionLifecycle);}
        public void onEndpointLost(@NonNull String id){}
    };

    private final ConnectionLifecycleCallback connectionLifecycle=new ConnectionLifecycleCallback(){
        public void onConnectionInitiated(@NonNull String id,@NonNull ConnectionInfo info){nearby.acceptConnection(id,payloads);}
        public void onConnectionResult(@NonNull String id,@NonNull ConnectionResolution result){
            if(!result.getStatus().isSuccess()){setStatus("No se pudo conectar.");return;}
            if(host){players.put(id,"Jugador");completed.put(id,false);send(id,"WELCOME|"+players.size());broadcastRoster();renderPlayers();}
            else{hostEndpoint=id;players.put("HOST","Anfitrión");players.put(id,playerName);showLobby();send(id,"HELLO|"+playerName);}
        }
        public void onDisconnected(@NonNull String id){players.remove(id);completed.remove(id);runOnUiThread(()->{renderPlayers();if(!host)showHome();});}
    };

    private final PayloadCallback payloads=new PayloadCallback(){
        public void onPayloadReceived(@NonNull String id,@NonNull Payload p){if(p.getType()!=Payload.Type.BYTES||p.asBytes()==null)return;String m=new String(p.asBytes(),StandardCharsets.UTF_8);runOnUiThread(()->handle(id,m));}
        public void onPayloadTransferUpdate(@NonNull String id,@NonNull PayloadTransferUpdate u){}
    };

    private void handle(String id,String m){
        String[] a=m.split("\\|",-1);
        if(a[0].equals("HELLO")&&host){players.put(id,a[1]);broadcastRoster();renderPlayers();}
        else if(a[0].equals("ROSTER")){players.clear();for(int i=1;i<a.length;i++)players.put("P"+i,a[i]);renderPlayers();}
        else if(a[0].equals("START"))showMission(a[1],a[2],Integer.parseInt(a[3]));
        else if(a[0].equals("DONE")&&host)markDone(id);
        else if(a[0].equals("PROGRESS")&&status!=null)status.setText("Misiones completadas: "+a[1]+" / "+a[2]);
        else if(a[0].equals("END"))showResult(a[1].equals("WIN"));
    }

    private void broadcastRoster(){StringBuilder s=new StringBuilder("ROSTER");for(String p:players.values())s.append('|').append(p.replace("|",""));broadcast(s.toString());}
    private void broadcast(String m){for(String id:players.keySet())if(!id.equals("HOST"))send(id,m);}
    private void send(String id,String m){if(id==null)return;nearby.sendPayload(id,Payload.fromBytes(m.getBytes(StandardCharsets.UTF_8)));}
    private void stopNetwork(){if(nearby!=null){nearby.stopAdvertising();nearby.stopDiscovery();nearby.stopAllEndpoints();}if(timer!=null)timer.cancel();}

    private LinearLayout base(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER_HORIZONTAL);x.setPadding(dp(24),dp(52),dp(24),dp(36));x.setBackgroundColor(NAVY);return x;}
    private ScrollView scroll(View v){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.addView(v);return s;}
    private TextView label(String text,int sp,int color,boolean bold,int pad,int bottom){TextView t=new TextView(this);t.setText(text);t.setTextSize(sp);t.setTextColor(color);t.setGravity(Gravity.CENTER);t.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(t,params(-1,-2,0,0,0,bottom));return t;}
    private void smallIn(LinearLayout p,String text,int color){TextView t=new TextView(this);t.setText(text);t.setTextColor(color);t.setTextSize(17);t.setPadding(dp(8),dp(10),dp(8),dp(10));p.addView(t,new LinearLayout.LayoutParams(-1,-2));}
    private Button button(String text,int color){Button b=new Button(this);b.setText(text);b.setTextSize(16);b.setTextColor(color==MINT?NAVY:Color.WHITE);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(round(color,16));b.setAllCaps(false);return b;}
    private void addButton(String text,int color,View.OnClickListener click){Button b=button(text,color);b.setOnClickListener(click);root.addView(b,params(-1,58,0,8,0,10));}
    private void add(View v,int w,int h,int l,int t,int r,int b){root.addView(v,params(w,h,l,t,r,b));}
    private LinearLayout.LayoutParams params(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h<0?h:dp(h));p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void setStatus(String s){runOnUiThread(()->{if(status!=null)status.setText(s);});}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private boolean hasPermissions(){if(Build.VERSION.SDK_INT<31)return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE)==PackageManager.PERMISSION_GRANTED;}
    private void requestPermissionsIfNeeded(){List<String> p=new ArrayList<>();if(Build.VERSION.SDK_INT>=33)p.add(Manifest.permission.NEARBY_WIFI_DEVICES);if(Build.VERSION.SDK_INT>=31){p.add(Manifest.permission.BLUETOOTH_SCAN);p.add(Manifest.permission.BLUETOOTH_CONNECT);p.add(Manifest.permission.BLUETOOTH_ADVERTISE);}else p.add(Manifest.permission.ACCESS_FINE_LOCATION);requestPermissions(p.toArray(new String[0]),PERMISSION_REQUEST);}
    @Override public void onRequestPermissionsResult(int r,@NonNull String[] p,@NonNull int[] g){super.onRequestPermissionsResult(r,p,g);if(r==PERMISSION_REQUEST&&!hasPermissions())toast("La conexión cercana necesita estos permisos.");}
    @Override protected void onDestroy(){stopNetwork();super.onDestroy();}
}
