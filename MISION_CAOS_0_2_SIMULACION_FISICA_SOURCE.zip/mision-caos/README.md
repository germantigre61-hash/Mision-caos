# Misión Caos - prototipo Android 0.1

Juego presencial y sin internet para 3 a 8 personas en esta primera prueba. La arquitectura usa Nearby Connections con topología estrella y está preparada para ampliar las pruebas hasta 25 jugadores.

## Qué incluye

- Crear una sala desde un teléfono anfitrión.
- Descubrir y unir teléfonos cercanos sin internet.
- Lista sincronizada de participantes.
- Roles secretos de agente e infiltrado (desde 5 jugadores).
- Diez misiones sociales rotativas.
- Temporizador de cinco minutos y progreso compartido.
- Pantalla de victoria o derrota.

## Generar el APK

1. Abrir esta carpeta con Android Studio.
2. Esperar que termine la sincronización inicial.
3. Elegir `Build > Build APK(s)`.
4. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

Instalar el mismo APK en todos los teléfonos. Al abrirlo, aceptar los permisos de dispositivos cercanos. Un teléfono toca `CREAR SALA`; los demás, `UNIRME A UNA SALA`.

## Prueba recomendada

Primero probar con tres teléfonos juntos. Después repetir con cinco o más para activar el infiltrado. Mantener Bluetooth y Wi-Fi encendidos, aunque no haya acceso a internet.

## Cambios 0.2
- Botón de simulación local con 4 jugadores automáticos.
- Misiones físicas nuevas (agitar, girar, apoyar, foto grupal, carrera corta).
- La misión de agitar usa el acelerómetro real y vibración háptica.
- Simulación automática de progreso para probar sin reunir personas.
- Interfaz preparada conceptualmente para ampliar las pruebas hasta 25 jugadores.
